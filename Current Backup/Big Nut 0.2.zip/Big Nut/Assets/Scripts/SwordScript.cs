﻿using UnityEngine;
using System.Collections;

public class SwordScript : MonoBehaviour
{
    public string sOwner;

    public void Stab()
    {
        print("stabby");
    }

}
